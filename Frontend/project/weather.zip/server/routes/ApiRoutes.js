const router=require ("express").Router()
const categoryController=require("../apis/category/categoryController")
router.post ("/category/add",categoryController.add)
module.exports=router
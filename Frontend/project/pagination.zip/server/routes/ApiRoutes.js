const CategoryController = require("../apis/category/CategoryController")
const ProductController= require("../apis/product/ProductController")
const brandController=require("../apis/brand/brandController")

const router=require("express").Router()
router.post ("/category/add", CategoryController.add)
router.post ("/category/all", CategoryController.all)

router.post ("/product/add", ProductController.add)

router.post ("/brand/add", brandController.add)
router.post ("/brand/all", brandController.all)


module.exports=router
const UserModel = require("./UserModel")
const bcryptjs=require("bcryptjs")
const jwt=require("jsonwebtoken")
const SECRET="StraytoStay"
login=(req,res)=>{
    let validation=""
    let formData=req.body
    if(!formData.email){
      validation+="Email is required"
    }
    if(!formData.password){
        validation+=" Password is required"
    }
    if(!!validation.trim()){
        res.json({
            status:422,
            success:false,
            message:validation
        })
    }else{
        UserModel.findOne({email:formData.email})
        .then((userData)=>{
            if(!userData){
                res.json({
                    status:404,
                    success:false,
                    message:"User doesn't exist!"
                })

}else{
    let result=  bcryptjs.compareSync(formData.password, userData.password)
   
    
    if(result){
      let payload={
          userId:userData._id,
          email:userData.email,
          userType:userData.userType,
          name:userData.name
      }
      let token=jwt.sign(payload, SECRET, {expiresIn:"24h"})
      res.json({
          status:200,
          success:true,
          message:"Login successfully!!",
          token,
          data:userData
      })
    }else{
      res.json({
          status:200,
          success:false,
          message:"Invalid credentials"
      })
    }
    
  }
  
})
.catch((err)=>{
  res.json({
      status:500,
      success:false,
      message:"Internal server error!!!"
  })
})
}
}

module.exports={login}
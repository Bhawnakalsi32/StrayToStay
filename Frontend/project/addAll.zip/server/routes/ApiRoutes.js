const CategoryController = require("../apis/category/CategoryController")
const ProductController= require("../apis/product/ProductController")

const router=require("express").Router()
router.post ("/category/add", CategoryController.add)
router.post ("/category/all", CategoryController.all)
router.post ("/product/add", ProductController.add)
router.post ("/product/all", ProductController.all)

module.exports=router
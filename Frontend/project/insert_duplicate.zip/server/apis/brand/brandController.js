const brandModel=require("./brandModel")
add=(req,res)=>{
    brandModel.findOne({brandModel:req.body.brandName})
    .then(async(brandData)=>{
        if(!brandData){

            let brandObj= new brandModel();

            brandObj.brandName=req.body.brandName,
             brandObj.save()
             .then((brandData)=>{
                 res.json({
                     status:200,
                     success:true,
                     message:"brand Added",
                     data:brandData,
                 })
             })
             .catch((err)=>{
                 res.json({
                     status:500,
                     success:false,
                     message:"internal server error",
                     error:err
                 })
             })
         
        }
        else{
            res.json({
                status:200,
                success:true,
                message:"Category already exist with same name",
                data:brandData
            })
           }
            
        })
        .catch((err)=>{
            res.json({
                status:500,
                success:false,
                message:"Internal server error!",
                error:err
            })
        })
    }
    
module.exports={add}
const mongoose=require("mongoose")
let CategorySchema=mongoose.Schema({
    categoryName:{type:String, default:""},
    autoId:{type:Number, default:0},
    status:{type:Boolean, default:true},
    createdAt:{type:Date, default:Date.now()}
})

module.exports=mongoose.model("CategoryModel", CategorySchema)
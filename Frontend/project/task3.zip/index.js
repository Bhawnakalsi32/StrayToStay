const weather=require("weather-js")
const express=require("express")
const app=express()
const PORT=5000
const api=require("./server/routes/ApiRoutes")
const db=require("./server/config/db")
app.use("/api",api)
app.listen(PORT,()=>{
    console.log("SERVER is running at ", PORT);
  
})
// app.get("/",(req,res)=>{
//     res.json({
//         status:200,
//         success:true, 
//         message:"My name is Sunidhi"
//     })
// })

// app.post("/first",(req,res)=>{
//     res.json({
//         status:200,
//         success:true,
//         message:"GNDU RC JAL"
//     })
// })
// app.get("/scd",(req,res)=>{
//     res.json({
//         status:200,
//         success:true, 
//         message:"My hobby is Singing"
//     })
// })
// app.post("/thd",(req,res)=>{
//     res.json({
//         status:200,
//         success:true,
//         message:"Btect CSE"
//     })
// })
// app.get("/fth",(req,res)=>{
//     res.json({
//         status:200,
//         success:true, 
//         message:"MERN"
//     })
// })

// app.get("/weather" ,(req,res)=>{

//     weather.find({search: "jalandhar, punjab" , degreeType: 'F'}, function(err, result) {
//         if(err) console.log(err);
       
//         console.log(JSON.stringify(result, null, 2));
      
//         res.json({
//           status:200,
//           success:true,
//          data: result,
// })
//     });

//     })

// app.get("/weather/:y" ,(req,res)=>{
//     let y=req.params.y;
// weather.find({search: y , degreeType: 'F'}, function(err, result) {
//   if(err) console.log(err);
 
//   console.log(JSON.stringify(result, null, 2));

//   res.json({
//     status:200,
//     success:true,
//     x:result[0] . location.name,
//     y:result[0].current.temperature
//   })
// });
// })


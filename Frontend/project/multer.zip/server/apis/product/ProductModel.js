const mongoose=require("mongoose")
let ProductSchema=mongoose.Schema({
    image:{type:String, default:"no-pic.jpg"},
    productName:{type:String, default:""},
    autoId:{type:Number, default:0},
    status:{type:Boolean, default:true},
    createdAt:{type:Date, default:Date.now()}
})

module.exports=mongoose.model("ProductModel", ProductSchema)
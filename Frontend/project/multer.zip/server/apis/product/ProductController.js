const ProductModel = require("./ProductModel")

add=(req,res)=>{
    let validation=""
    let formData=req.body
    if(!formData.productName){
        validation+="Product name is required"
    }
    if(!!validation.trim()){
        res.json({
            status:422,
            success:false,
            message:validation
        })
    }else{
        
        ProductModel.findOne({productName:formData.productName})
        .then(async (ProductData)=>{
            if(!ProductData){
                let ProductObj=  new ProductModel()
                let total=await ProductModel.countDocuments().exec()
                ProductObj.productName=formData.productName
                ProductObj.image="product_images/"+req.file?.filename
                ProductObj.autoId=total+1 
                ProductObj.save()
                .then((ProductData)=>{
                    res.json({
                        success:true,
                        status:200,
                        message:"Product added!!",
                        data:ProductData
                    })
                })
                .catch((err)=>{
                    res.json({
                        status:500,
                        success:false,
                        message:"Internal server error",
                        error:err
                    }) 
                })
            }else{
                res.json({
                    status:200,
                    success:false,
                    message:"Product already exists",
                    data:ProductData
                })
            }   
        })
        .catch((err)=>{
            res.json({
                status:500,
                success:false,
                message:"Internal server error",
                error:err
            })
        })
    }
}

all=(req,res)=>{
    let formData=req.body
    let limit=formData.limit  
    let currentPage=formData.currentPage 
    delete formData.limit 
    delete formData.currentPage
   
    ProductModel.find(formData)
   .limit(limit)
    .skip((currentPage-1)*limit)
    
    .then(async (ProductData)=>{
        if(ProductData.length>0){
            let total=await ProductModel.countDocuments().exec()
            res.json({
                status:200,
                success:true,
                message:"Product loaded",
                total:total,
                data:ProductData
            })
        }else{
            res.json({
                status:404,
                success:false,
                message:"No Product Found!!",
                data:ProductData
            })
        }
        
    }) 
    .catch((err)=>{
        res.json({
            status:500,
            success:false,
            message:"Internal server error",
            error:err
        })
    })   
}

single=(req,res)=>{
    let validation=""
    let formData=req.body 
    if(!formData._id){
        validation+="_id is required"
    }
    if(!!validation.trim()){
        res.json({
            status:422,
            success:false,
            message:validation
        })
    }else{
        ProductModel.findOne({_id:formData._id})
        .then((ProductData)=>{
            if(!ProductData){
                res.json({
                    status:404,
                    success:false,
                    message:"No Product found!!"
                })
            }else{
                res.json({
                    status:200,
                    success:true,
                    message:"Product exists",
                    data:ProductData
                })
            }
            
        })
        .catch((err)=>{
            res.json({
                status:500,
                success:false,
                message:"Internal server error",
                error:err
            })
        })
    }
}

deleteProduct=(req,res)=>{
    let validation=""
    let formData=req.body 
    if(!formData._id){
        validation+="_id is required"
    }
    if(!!validation.trim()){
        res.json({
            status:422,
            success:false,
            message:validation
        })
    }else{
        ProductModel.findOne({_id:formData._id})
        .then((ProductData)=>{
            if(!ProductData){
                res.json({
                    status:404,
                    success:false,
                    message:"No Product found!!!"
                })
            }else{
                ProductModel.deleteOne({_id:formData._id})
                .then(()=>{
                    res.json({
                        success:true,
                        status:200,
                        message:"Product deleted"
                    })
                })
                .catch((err)=>{
                    res.json({
                        status:500,
                        success:false,
                        message:"Internal server error",
                        error:err
                    })
                })
            }         
        })
        .catch((err)=>{
            res.json({
                status:500,
                success:false,
                message:"Internal server error",
                error:err
            })
        })
    }
}


update=(req,res)=>{
    let formData=req.body 
    let validation=""
    if(!formData._id){
        validation+="_id is required"
    }
    if(!!validation.trim()){
        res.json({
            status:422,
            success:false,
            message:validation
        })
    }else{
        ProductModel.findOne({_id:formData._id})
        .then((ProductData)=>{
            if(!ProductData){
                res.json({
                    status:404,
                    success:false,
                    message:"No Product found!!"
                })
            }else{
                if(!!formData.ProductName){
                    ProductData.ProductName=formData.ProductName 
                }
                if(!!formData.image){
                    ProductData.image=formData.image 
                }
               ProductData.save()
               .then((ProductData)=>{
                    res.json({
                        status:200,
                        success:true,
                        message:"Product updated successfully!!",
                        data:ProductData
                    })
               })
               .catch((err)=>{
                    res.json({
                        status:500,
                        success:false,
                        message:"Internal server error",
                        error:err
                    })
               }) 
            }
            
        })
        .catch((err)=>{
            res.json({
                status:500,
                success:false,
                message:"Internal server error",
                error:err
            })
        })
    }

    // find given _id 
    //update

}

changeStatus=(req,res)=>{
    let validation=""
    let formData=req.body 
    if(!formData._id){
        validation+="_id is required"
    }
    
    if(!!validation.trim()){
        res.json({
            status:422,
            success:false,
            message:validation
        })
    }else{
        ProductModel.findOne({_id:formData._id})
        .then((ProductData)=>{
            if(!ProductData){
                res.json({
                    status:404,
                    success:false,
                    message:"No Product found!!"
                })
            }else{
            // ProductData.status=!ProductData.status 
               ProductData.status=formData.status 
               ProductData.save()
               .then((ProductData)=>{
                    res.json({
                        status:200,
                        success:true,
                        message:"Status updated successfully",
                        data:ProductData
                    })
               })
               .catch((err)=>{
                    res.json({
                        status:500,
                        success:false,
                        message:"Internal server error",
                        error:err
                    })
            })

            }
        })
        .catch((err)=>{
            res.json({
                status:500,
                success:false,
                message:"Internal server error",
                error:err
            })
        })
    }
}

module.exports={add, all, single, deleteProduct, update, changeStatus}
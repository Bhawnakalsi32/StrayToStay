const ProductModel = require("./ProductModel");

add=(req, res)=> {
          let productObj = new ProductModel();


          productObj.productName = req.query.productName;
          productObj.autoId=req.query.autoId;
          productObj.productDescription = req.query.productDescription;

          productObj.save()
                    .then((productData) => {
                              res.json({
                                        status: 200,
                                        success: true,
                                        message: "product Added!!",
                                        data: productData
                              });
                    })
                    .catch((err) => {
                              res.json({
                                        status: 500,
                                        success: false,
                                        message: "Internal server error!",
                                        error: err
                              });
                    });
};
 all=(req,res)=>{
    res.json({
        status:200,
        success:true,
        message:"All api is working"
    })
 }
module.exports = {add,all};
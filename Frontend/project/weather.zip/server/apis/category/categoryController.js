add ((req , res)=>{
    console.log("hello");
})
model.exports={add}
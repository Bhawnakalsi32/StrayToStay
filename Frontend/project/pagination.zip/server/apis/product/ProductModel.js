const mongoose=require("mongoose")
let ProductSchema=mongoose.Schema({
    productName:{type:String, default:""},
    autoId:{type:Number, default:0},
    status:{type:Boolean, default:true},
    createdAt:{type:Date, default:Date.now()}
})

module.exports=mongoose.model("ProductModel", ProductSchema)
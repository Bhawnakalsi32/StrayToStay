const ProductModel = require("./ProductModel");

add=(req, res)=> {
          let productObj = new ProductModel();


          productObj.productName = req.query.productName;
          productObj.autoId=req.query.autoId;
          productObj.productcategory = req.query.productCategory;
          productObj.productBrand = req.query.productBrand;
          productObj.productPrice = req.query.productPrice;
          productObj.productQuantity = req.query.productQuantity;
          productObj.productDescription = req.query.productDescription;
          productObj.save()
                    .then((productData) => {
                              res.json({
                                        status: 200,
                                        success: true,
                                        message: "product Added!!",
                                        data: productData
                              });
                    })
                    .catch((err) => {
                              res.json({
                                        status: 500,
                                        success: false,
                                        message: "Internal server error!",
                                        error: err
                              });
                    });
};
module.exports = {add};
const multer= require("multer")
const CategoryController = require("../apis/category/CategoryController")
const ProductController= require("../apis/product/ProductController")
const brandController=require("../apis/brand/brandController")
const UserModel=require("../apis/user/UserModel")
const UserController=require("../apis/user/UserController")
const CustomerController=require("../apis/customer/CustomerController")

const router=require("express").Router()
router.post ("/category/add", CategoryController.add)
router.post ("/category/all", CategoryController.all)
const productStorage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, './server/public/product_images/')
    },
    filename: function (req, file, cb) {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
      cb(null, file.fieldname + '-' + uniqueSuffix + "-" + file.originalname)
    }
})
const productUpload = multer({ storage: productStorage })
router.post("/product/add", productUpload.single("image"),ProductController.add)
router.post("/product/all", ProductController.all)
router.post("/product/single", ProductController.single)
router.post("/product/delete", ProductController.deleteProduct)
router.post("/product/update", ProductController.update)
router.post("/product/changeStatus", ProductController.changeStatus)

router.post("/brand/add", brandController.add)
router.post("/brand/all", brandController.all)
router.post("/brand/single", brandController.single)
router.post("/brand/delete", brandController.deleteBrand)
router.post("/brand/update", brandController.update)
router.post("/brand/changeStatus", brandController.changeStatus)


router.post("/user/login", UserController.login)
router.post("/customer/register", CustomerController.register)
module.exports=router


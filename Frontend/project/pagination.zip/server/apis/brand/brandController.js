const brandModel = require("./brandModel")

add=(req,res)=>{
    let validation=""
    let formData=req.body
    if(!formData.brandName){
        validation+="Brand name is required"
    }
    if(!!validation.trim()){
        res.json({
            status:422,
            success:false,
            message:validation
        })
    }else{
        //duplicacy 
        brandModel.findOne({brandName:formData.brandName})
        .then(async (brandData)=>{
            if(!brandData){
                let brandObj=  new brandModel()
                // console.log(brandObj);
                let total=await brandModel.countDocuments().exec()
                brandObj.brandName=formData.brandName
                brandObj.autoId=total+1 
                brandObj.save()
                .then((brandData)=>{
                    res.json({
                        success:true,
                        status:200,
                        message:"Brand added!!",
                        data:brandData
                    })
                })
                .catch((err)=>{
                    res.json({
                        status:500,
                        success:false,
                        message:"Internal server error",
                        error:err
                    }) 
                })
            }else{
                res.json({
                    status:200,
                    success:false,
                    message:"Brand already exists",
                    data:brandData
                })
            }   
        })
        .catch((err)=>{
            res.json({
                status:500,
                success:false,
                message:"Internal server error",
                error:err
            })
        })
    }
}

all=(req,res)=>{
    let formData=req.body
    let limit=formData.limit  
    let currentPage=formData.currentPage 
    delete formData.limit 
    delete formData.currentPage
    brandModel.find(formData)
   .limit(limit)
    .skip((currentPage-1)*limit)
    .then(async (brandData)=>{
        if(brandData.length>0){
            let total=await brandModel.countDocuments().exec()
            res.json({
                status:200,
                success:true,
                message:"Brand loaded",
                total:total,
                data:brandData
            })
        }else{
            res.json({
                status:404,
                success:false,
                message:"No brand Found!!",
                data:brandData
            })
        }
        
    }) 
    .catch((err)=>{
        res.json({
            status:500,
            success:false,
            message:"Internal server error",
            error:err
        })
    })   
}
module.exports={add, all}
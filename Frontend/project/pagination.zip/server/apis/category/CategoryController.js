const CategoryModel = require("./CategoryModel")
add = (req, res) => {
    let validation = ""
    let formData = req.body
    if (!formData.categoryName) {
        validation += "Category name is required"
    }
    if (!!validation.trim()) {
        res.json({
            status: 422,
            success: false,
            message: validation
        })
    } else {
        CategoryModel.findOne({ categoryName: formData.categoryName })
            .then(async (CategoryData) => {
                if (!CategoryData) {
                    let CategoryObj = new CategoryModel()
                    let total = await CategoryModel.countDocuments().exec()
                    CategoryObj.categoryName = formData.categoryName
                    CategoryObj.autoId = total + 1
                    CategoryObj.save()
                        .then((CategoryData) => {
                            res.json({
                                success: true,
                                status: 200,
                                message: "Category added!!",
                                data: CategoryData
                            })
                        })
                        .catch((err) => {
                            res.json({
                                status: 500,
                                success: false,
                                message: "Internal server error",
                                error: err
                            })
                        })
                } else {
                    res.json({
                        status: 200,
                        success: false,
                        message: "Categoryalready exists",
                        data: CategoryData
                    })
                }
            })
            .catch((err) => {
                res.json({
                    status: 500,
                    success: false,
                    message: "Internal server error",
                    error: err
                })
            })
    }
}

all=(req,res)=>{
    let formData=req.body 
    let limit=formData.limit
    let currentPage=formData.currentPage 
        delete formData.limit 
        delete formData.currentPage
        CategoryModel.find(formData)
       .limit(limit)
        .skip((currentPage-1)*limit)
        .then(async (CategoryData)=>{
            if(CategoryData.length>0){
                let total=await CategoryModel.countDocuments().exec()
                res.json({
                    status:200,
                    success:true,
                    message:"Category loaded",
                    total:total,
                    data:CategoryData
                })
            }else{
                res.json({
                    status:404,
                    success:false,
                    message:"No Category Found!!",
                    
                })
            }
            
        }) 
        .catch((err)=>{
            res.json({
                status:500,
                success:false,
                message:"Internal server error",
                error:err
            })
        })   
    }
    module.exports={add, all}

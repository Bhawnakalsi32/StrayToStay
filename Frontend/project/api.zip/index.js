
const express=require("express")
const app=express()
const PORT=5000
app.listen(PORT,()=>{
    console.log("SERVER is running at ", PORT);
})
app.get("/",(req,res)=>{
    res.json({
        status:200,
        success:true, 
        message:"My name is Sunidhi"
    })
})

app.post("/first",(req,res)=>{
    res.json({
        status:200,
        success:true,
        message:"GNDU RC JAL"
    })
})
app.get("/scd",(req,res)=>{
    res.json({
        status:200,
        success:true, 
        message:"My hobby is Singing"
    })
})
app.post("/thd",(req,res)=>{
    res.json({
        status:200,
        success:true,
        message:"Btect CSE"
    })
})
app.get("/fth",(req,res)=>{
    res.json({
        status:200,
        success:true, 
        message:"MERN"
    })
})
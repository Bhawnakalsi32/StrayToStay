const mongoose=require("mongoose")
let ProductSchema=mongoose.Schema({
    productName:{type:String, default:""},
    productCategory:{type:String, default:""},
    autoId:{type:Number, default:0},
    productbrand:{type:String, default:""},
    productPrice:{type:Number, default:0},
    productquantity:{type:Number, default:0},
    productDescription:{type:String, default:""},
    status:{type:Boolean, default:true},
    createdAt:{type:Date, default:Date.now()}
})

module.exports=mongoose.model("ProductModel", ProductSchema)
const brandModel=require("./brandModel")
add=(req,res)=>{
    let brandObj= new brandModel();

       brandObj.brandName=req.query.brandName,
        brandObj.save()
        .then((brandData)=>{
            res.json({
                status:200,
                success:true,
                message:"brand Added",
                data:brandData,
            })
        })
        .catch((err)=>{
            res.json({
                status:500,
                success:false,
                message:"internal server error",
                error:err
            })
        })
    
}
module.exports={add}